#include "raylib.h"
#include "globals.h"
// TODO

int main() {
    SetConfigFlags(FLAG_VSYNC_HINT | FLAG_MSAA_4X_HINT);
    InitWindow(GetMonitorWidth(0), GetMonitorHeight(1), "Dungeon");
    SetTargetFPS(60);
    ToggleFullscreen();
    HideCursor();

    // TODO

    while (!WindowShouldClose()) {
        BeginDrawing();

        // TODO

        EndDrawing();
    }
    CloseWindow();

    // TODO

    return 0;
}
